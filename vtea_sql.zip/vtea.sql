-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2023 at 08:30 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vtea`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `id` int(11) NOT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0' COMMENT '0:Chờ lấy hàng, 1:Đang vận chuyển,2:Đã nhận',
  `pttt` varchar(255) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`id`, `tel`, `address`, `total`, `status`, `pttt`, `id_user`, `created_at`, `updated_at`) VALUES
(1, '1111111111', 'fdhvjshbghkjlfdslh', '128', '0', 'Thanh toán khi nhận hàng', 11, '2022-11-02 11:03:10', '0000-00-00 00:00:00'),
(2, '1111111111', 'fdhvjshbghkjlfdslh', '150', '0', 'Paypal', 11, '2022-11-02 11:06:20', '0000-00-00 00:00:00'),
(3, '1111111111', 'fdhvjshbghkjlfdslh', '420.42', '2', 'Vnpay', 11, '2022-11-02 11:07:26', '2022-11-05 13:37:27'),
(4, '0123456789', 'An Giang, Châu Phú', '223.21', '0', 'Paypal', 16, '2022-11-02 14:21:22', '0000-00-00 00:00:00'),
(5, '0979799490', 'Đại học Cần Thơ, 3/2, Xuân Khánh, Ninh Kiều, Cần Thơ', '18', '2', 'Paypal', 11, '2022-11-02 16:32:28', '2022-11-05 13:38:21');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `created_at`, `updated_at`) VALUES
(15, 'Black Tea', '2022-08-24 15:11:57', NULL),
(16, 'Flowering Tea ', '2022-08-24 15:12:14', '2022-08-24 15:13:43'),
(17, 'Fruit Tea ', '2022-08-24 15:12:25', NULL),
(18, 'Green Tea ', '2022-08-24 15:12:38', NULL),
(19, 'Herbal Tea ', '2022-08-24 15:12:47', NULL),
(20, 'Red Tea ', '2022-08-24 15:12:56', NULL),
(24, 'Organic green Tea', '2022-11-05 23:51:34', '2022-11-05 23:52:04');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `product_id`, `user_id`, `content`, `rating`, `created_at`, `updated_at`) VALUES
(21, 17, 11, 'DJFGJBSDNGB', 4, '2022-11-01 11:16:44', NULL),
(22, 17, 11, 'GƯGFEHEWRBNMS', 5, '2022-11-01 11:17:55', NULL),
(23, 17, 11, 'GƯGFEHEWRBNMS', 5, '2022-11-01 11:17:58', NULL),
(24, 17, 11, 'ưefvhernsmdsfuygfreu', 3, '2022-11-01 11:18:14', NULL),
(25, 17, 11, 'asghsdv nbv', 1, '2022-11-01 11:18:43', NULL),
(26, 17, 11, 'sssss', 5, '2022-11-01 11:36:00', NULL),
(27, 14, 11, 'hello', 4, '2022-11-03 23:35:54', NULL),
(28, 14, 11, 'hi!', 4, '2022-11-03 23:36:13', NULL),
(29, 17, 11, 'dfffffffffff', 4, '2022-11-03 23:37:01', NULL),
(30, 17, 11, 'hello', 4, '2022-11-05 23:41:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `detail_bill`
--

CREATE TABLE `detail_bill` (
  `id` bigint(20) NOT NULL,
  `id_bill` int(11) DEFAULT NULL,
  `id_pro` int(11) DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `total` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `name_pro` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `detail_bill`
--

INSERT INTO `detail_bill` (`id`, `id_bill`, `id_pro`, `number`, `total`, `price`, `img`, `name_pro`, `created_at`, `updated_at`) VALUES
(1, 1, 17, 1, '8', '8.00', 'Hezb Mentha Spicata.jpg', 'Hezb Mentha Spicata', '2022-11-02 04:03:10', NULL),
(2, 1, 16, 1, '110', '110.00', 'Jasmine Scented Green Tea.jpg', 'Jasmine Scented GreenTea', '2022-11-02 04:03:10', NULL),
(3, 2, 16, 1, '110', '110.00', 'Jasmine Scented Green Tea.jpg', 'Jasmine Scented GreenTea', '2022-11-02 04:06:20', NULL),
(4, 2, 12, 1, '30', '30.00', 'Jasmin Flowering Tea.jpg', 'Jasmin Flowering Tea', '2022-11-02 04:06:20', NULL),
(5, 3, 16, 2, '220', '110.00', 'Jasmine Scented Green Tea.jpg', 'Jasmine Scented GreenTea', '2022-11-02 04:07:26', NULL),
(6, 3, 15, 2, '190.42', '95.21', 'Green Snail Spring Tea.jpg', 'Green Snail Spring Tea', '2022-11-02 04:07:26', NULL),
(7, 4, 16, 1, '110', '110.00', 'Jasmine Scented Green Tea.jpg', 'Jasmine Scented GreenTea', '2022-11-02 07:21:22', NULL),
(8, 4, 17, 1, '8', '8.00', 'Hezb Mentha Spicata.jpg', 'Hezb Mentha Spicata', '2022-11-02 07:21:22', NULL),
(9, 4, 15, 1, '95.21', '95.21', 'Green Snail Spring Tea.jpg', 'Green Snail Spring Tea', '2022-11-02 07:21:22', NULL),
(10, 5, 17, 1, '8', '8.00', 'Hezb Mentha Spicata.jpg', 'Hezb Mentha Spicata', '2022-11-02 09:32:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `permission`, `created_at`, `updated_at`) VALUES
(1, 'Admin', NULL, '2022-08-26 06:55:05', '2022-11-02 15:12:39'),
(2, 'Client', NULL, '2022-08-26 06:55:05', '2022-11-02 15:12:49'),
(7, 'Client_Vip2', NULL, '2022-11-05 23:54:33', '2022-11-05 23:55:21');

-- --------------------------------------------------------

--
-- Table structure for table `image_product`
--

CREATE TABLE `image_product` (
  `id` int(11) NOT NULL,
  `path_img` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `image_product`
--

INSERT INTO `image_product` (`id`, `path_img`, `product_id`, `created_at`, `updated_at`) VALUES
(76, 'Hezb Mentha Spicata.jpg', 17, 2022, 0),
(77, 'hms1.jpg', 17, 2022, 0),
(78, 'hms3.jpg', 17, 2022, 0),
(82, 'Green Snail Spring Tea.jpg', 15, 2022, 0),
(83, 'mate1.jpg', 15, 2022, 0),
(84, 'Green Snail Spring Tea.jpg', 14, 2022, 0),
(85, 'Mate Tea With Monazda.jpg', 14, 2022, 0),
(86, 'mate1.jpg', 14, 2022, 0),
(90, 'Jasmine Scented Red Tea.jpg', 13, 2022, 0),
(91, 'j-red1.jpg', 13, 2022, 0),
(92, 'j-red3.jpg', 13, 2022, 0),
(93, 'Jasmine Scented Green Tea.jpg', 16, 2022, 0),
(94, 'jsg1.jpg', 16, 2022, 0),
(95, 'jsr3.jpg', 16, 2022, 0),
(96, 'Jasmin Flowering Tea.jpg', 12, 2022, 0),
(97, 'jf1.jpg', 12, 2022, 0),
(98, 'jf2.jpg', 12, 2022, 0),
(99, 'Hibiscus Calyces.jpg', 11, 2022, 0),
(100, 'hibiscus3.jpg', 11, 2022, 0),
(101, 'hibisus1.jpg', 11, 2022, 0),
(102, 'Hezb Oziganum Vulgaze.jpg', 10, 2022, 0),
(103, 'h-o1.jpg', 10, 2022, 0),
(104, 'h-o3.jpg', 10, 2022, 0),
(105, 'Hezb Mazzubium Vulgaze.jpg', 9, 2022, 0),
(106, 'hmv2.jpg', 9, 2022, 0),
(107, 'hmv3.jpg', 9, 2022, 0),
(108, 'Oragnic Green Tea.jpg', 7, 2022, 0),
(109, 'oragnic2.jpg', 7, 2022, 0),
(110, 'oragnic3.jpg', 7, 2022, 0),
(111, 'Black Unpzessed Tea.jpg', 6, 2022, 0),
(112, 'black1.jpg', 6, 2022, 0),
(113, 'black3.jpg', 6, 2022, 0),
(114, 'anxi1.jpg', 5, 2022, 0),
(115, 'anxi2.jpg', 5, 2022, 0),
(116, 'anxi3.jpg', 5, 2022, 0);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Home', '2022-08-30 11:19:23', '2022-08-30 11:21:41'),
(2, 'About Us', '2022-08-30 11:22:00', '2022-08-30 11:22:45'),
(3, 'Contact Us', '2022-08-30 11:22:07', '2022-08-30 11:22:36'),
(4, 'Shop', '2022-08-30 11:22:18', NULL),
(5, 'Blog', '2022-08-30 11:22:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` varchar(10) DEFAULT '0',
  `describes` varchar(255) DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `idCate` int(11) DEFAULT NULL,
  `sales` int(11) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `img`, `price`, `describes`, `views`, `created_at`, `updated_at`, `idCate`, `sales`, `rate`) VALUES
(5, 'Anxi Tie Guan Yin Tea', 'Anxi Tie Guan Yin Tea.jpg', '64.27', '        Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.        ', 0, '2022-08-24 15:33:12', '2022-09-15 10:26:26', 15, NULL, NULL),
(6, 'Black Unpzessed Tea', 'Black Unpzessed Tea.jpg', '28.00', '        Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.\r\n        ', 0, '2022-08-24 15:34:20', '2022-09-15 10:25:28', 15, NULL, NULL),
(7, 'Oragnic Green Tea', 'Oragnic Green Tea.jpg', '90.24', '        Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.        ', 0, '2022-08-24 15:35:25', '2022-09-15 10:25:09', 15, NULL, NULL),
(9, 'Hezb Mazzubium Vulgaze', 'Hezb Mazzubium Vulgaze.jpg', '45.00', '                Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.     ', 0, '2022-08-24 15:37:19', '2022-09-15 10:24:35', 16, NULL, NULL),
(10, 'Hezb Oziganum Vulgaze', 'Hezb Oziganum Vulgaze.jpg', '35.90', '        Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.        ', 0, '2022-08-24 15:38:26', '2022-09-15 10:22:43', 16, NULL, NULL),
(11, 'Hibiscus Calyces', 'Hibiscus Calyces.jpg', '24.00', '        Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.        ', 0, '2022-08-24 15:39:07', '2022-09-15 10:22:20', 16, NULL, NULL),
(12, 'Jasmin Flowering Tea', 'Jasmin Flowering Tea.jpg', '30.00', '         Sed egestas, ante et vulputate volutpat, eros pede semper est, vitae luctus metus libero eu augue. Morbi purus liberpuro ate vol faucibus adipiscing.Sed lectus te et vulputate aucibus adipiscing. Sed lectus. us adipiscing. Sed lectus.\r\n        ', 0, '2022-08-24 15:45:24', '2022-09-15 10:22:04', 16, NULL, NULL),
(13, 'Jasmine Scented Red Tea ', 'Jasmine Scented Red Tea.jpg', '110.00', '                 Jasmine Scented Red Tea                                                                                                                                                                                                                       ', 0, '2022-08-24 15:46:25', '2022-09-15 10:20:09', 17, NULL, NULL),
(14, 'Mate Tea With Monazda', 'Mate Tea With Monazda.jpg', '110.00', '        Mate Tea With Monazda        ', 0, '2022-08-24 15:47:02', '2022-09-15 10:18:00', 16, NULL, NULL),
(15, 'Green Snail Spring Tea', 'Green Snail Spring Tea.jpg', '95.21', '                Green Snail Spring Tea                ', 0, '2022-08-24 16:06:38', '2022-09-15 10:17:25', 18, NULL, NULL),
(16, 'Jasmine Scented GreenTea', 'Jasmine Scented Green Tea.jpg', '110.00', '                Jasmine Scented Green Tea                ', 0, '2022-08-24 17:32:29', '2022-09-15 10:21:34', 18, NULL, NULL),
(17, 'Hezb Mentha Spicata', 'Hezb Mentha Spicata.jpg', '8.00', '        Hezb Mentha Spicata        ', 0, '2022-08-24 17:34:05', '2022-09-15 10:16:05', 19, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `config_key` varchar(255) DEFAULT NULL,
  `config_value` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `config_key`, `config_value`, `created_at`, `updated_at`) VALUES
(9, 'Facebook', 'https://www.facebook.com/ ', '2022-08-31 10:03:40', NULL),
(10, 'Twitter', 'https://twitter.com/?lang=vi ', '2022-08-31 10:14:56', NULL),
(11, 'Instagram', 'https://www.instagram.com/ ', '2022-08-31 10:15:31', '2022-09-06 14:38:40'),
(18, 'Logo', 'cropped-site_logo_276x106.png', '2022-08-31 11:23:22', '2022-09-08 21:40:58'),
(21, 'Linkedin', 'https://www.linkedin.com/', '2022-09-18 17:05:12', NULL),
(22, 'Pinterest', 'https://www.pinterest.com/', '2022-09-18 17:06:46', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `caption`, `img`, `title`, `created_at`, `updated_at`) VALUES
(2, 'Organic Tea Shop', 'header-bg2.jpg', 'Discover the Process of Making Tea', '2022-08-29 15:10:20', '2022-08-30 10:50:34'),
(4, 'Organic Tea Shop', 'header-bg.jpg', 'Find the organic', '2022-08-30 10:15:29', '2022-08-30 10:43:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `tel` varchar(10) DEFAULT NULL,
  `idGroups` int(11) NOT NULL,
  `avt` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `password`, `email`, `address`, `tel`, `idGroups`, `avt`, `created_at`, `updated_at`) VALUES
(11, 'Nguyễn Trâm', '$2y$10$.mquzCN8CLTuBKe1pnlFtOchjnrCJaw4JjqxeKHJCTdjjBqrWeP5W', 'tram@gmail.com', 'Đại học Cần Thơ, 3/2, Xuân Khánh, Ninh Kiều, Cần Thơ', '0979799490', 1, 'z3801640371721_9a31d8f8b8ab0a865c0e555894ceb967.jpg', NULL, '2022-11-02 15:38:37'),
(15, 'us', '$2y$10$bfdgIURICvzMQGSVy2mrAuVNmc/S8g4aLIjkD9e9pxOLQKAj2iOTu', 'tramb1910316@student.ctu.edu.vn', 'thạnh long châu hưng a ', '0123456789', 1, '', '2022-08-30 10:45:50', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `work`
--

CREATE TABLE `work` (
  `id` int(11) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `detail_bill`
--
ALTER TABLE `detail_bill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image_product`
--
ALTER TABLE `image_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idCate` (`idCate`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idGroups` (`idGroups`);

--
-- Indexes for table `work`
--
ALTER TABLE `work`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `detail_bill`
--
ALTER TABLE `detail_bill`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `image_product`
--
ALTER TABLE `image_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `work`
--
ALTER TABLE `work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`idCate`) REFERENCES `category` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`idGroups`) REFERENCES `groups` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
